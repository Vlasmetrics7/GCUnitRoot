
function [FG_ASINT]=FG_TEO(T)

y=randn(T,1);Ey=cumsum(y);
x=randn(T,1);Ex=cumsum(x);

E2y=sum(Ey.^2)/(T^2);
E2x=sum(Ex.^2)/(T^2);
EUy=sum(Ey.*y)/(T);
Eyx=sum(Ey.*Ex)/(T^2);
ExUy=sum(Ex.*y)/(T);
%U2y=sum(y.^2)/(T)
U2y=1;

FG_ASINT=(((E2y*ExUy)-(EUy*Eyx))^2)/(E2y*U2y*(E2x*E2y-(Eyx^2)));



