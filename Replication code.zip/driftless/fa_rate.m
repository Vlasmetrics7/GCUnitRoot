% R es repeticiones monte carlo
% alpha es el nivel cr�tico de la asint�tica
function  fa_rate(R)
tic
Tb=[25,50,100,250,500,1000,10000];
%alpha=[8.09,7.17,6.97,6.94,6.61,6.5544,6.5867];
alpha=6.45;

for i=1:R
    
    for j=1:7
        T=Tb(j);
        F_GRANGER1(i,j)=GC_SD(0.7071,0.7071,T);
        F_GRANGER2(i,j)=GC_SD(0.7071,1,T);
        F_GRANGER3(i,j)=GC_SD(0.7071,1.2247,T);
        F_GRANGER4(i,j)=GC_SD(0.7071,1.4142,T);
        F_GRANGER5(i,j)=GC_SD(1,0.7071,T);
        F_GRANGER6(i,j)=GC_SD(1,1,T);
        F_GRANGER7(i,j)=GC_SD(1,1.2247,T);
        F_GRANGER8(i,j)=GC_SD(1,1.4142,T);
        F_GRANGER9(i,j)=GC_SD(1.2247,0.7071,T);
        F_GRANGER10(i,j)=GC_SD(1.2247,1,T);
        F_GRANGER11(i,j)=GC_SD(1.2247,1.5,T);
        F_GRANGER12(i,j)=GC_SD(1.2247,1.4142,T);
        F_GRANGER13(i,j)=GC_SD(1.4142,0.7071,T);
        F_GRANGER14(i,j)=GC_SD(1.4142,1,T);
        F_GRANGER15(i,j)=GC_SD(1.4142,1.2247,T);
        F_GRANGER16(i,j)=GC_SD(1.4142,1.4142,T);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%FGRANGER1
for j=1:7    
    for i=1:R
    if  (F_GRANGER1(i,j) > alpha);
        Trech1(i,j)=1;
    elseif (F_GRANGER1(i) <= alpha);
        Trech1(i,j)=0;
    end
    end
end

%FGRANGER2
for j=1:7    
    for i=1:R
    if  (F_GRANGER2(i,j) > alpha);
        Trech2(i,j)=1;
    elseif (F_GRANGER2(i) <= alpha);
        Trech2(i,j)=0;
    end
    end
end
%FGRANGER3
for j=1:7    
    for i=1:R
    if  (F_GRANGER3(i,j) > alpha);
        Trech3(i,j)=1;
    elseif (F_GRANGER3(i) <= alpha);
        Trech3(i,j)=0;
    end
    end
end
%FGRANGER4
for j=1:7    
    for i=1:R
    if  (F_GRANGER4(i,j) > alpha);
        Trech4(i,j)=1;
    elseif (F_GRANGER4(i) <= alpha);
        Trech4(i,j)=0;
    end
    end
end
%FGRANGER5
for j=1:7    
    for i=1:R
    if  (F_GRANGER5(i,j) > alpha);
        Trech5(i,j)=1;
    elseif (F_GRANGER5(i) <= alpha);
        Trech5(i,j)=0;
    end
    end
end
%FGRANGER6
for j=1:7    
    for i=1:R
    if  (F_GRANGER6(i,j) > alpha);
        Trech6(i,j)=1;
    elseif (F_GRANGER6(i) <= alpha);
        Trech6(i,j)=0;
    end
    end
end
%FGRANGER7
for j=1:7    
    for i=1:R
    if  (F_GRANGER7(i,j) > alpha);
        Trech7(i,j)=1;
    elseif (F_GRANGER7(i) <= alpha);
        Trech7(i,j)=0;
    end
    end
end
%FGRANGER8
for j=1:7    
    for i=1:R
    if  (F_GRANGER8(i,j) > alpha);
        Trech8(i,j)=1;
    elseif (F_GRANGER8(i) <= alpha);
        Trech8(i,j)=0;
    end
    end
end
%FGRANGER9
for j=1:7    
    for i=1:R
    if  (F_GRANGER9(i,j) > alpha);
        Trech9(i,j)=1;
    elseif (F_GRANGER9(i) <= alpha);
        Trech9(i,j)=0;
    end
    end
end
%FGRANGER10
for j=1:7    
    for i=1:R
    if  (F_GRANGER10(i,j) > alpha);
        Trech10(i,j)=1;
    elseif (F_GRANGER10(i) <= alpha);
        Trech10(i,j)=0;
    end
    end
end
%FGRANGER11
for j=1:7    
    for i=1:R
    if  (F_GRANGER11(i,j) > alpha);
        Trech11(i,j)=1;
    elseif (F_GRANGER11(i) <= alpha);
        Trech11(i,j)=0;
    end
    end
end
%FGRANGER12
for j=1:7    
    for i=1:R
    if  (F_GRANGER12(i,j) > alpha);
        Trech12(i,j)=1;
    elseif (F_GRANGER12(i) <= alpha);
        Trech12(i,j)=0;
    end
    end
end
%FGRANGER13
for j=1:7    
    for i=1:R
    if  (F_GRANGER13(i,j) > alpha);
        Trech13(i,j)=1;
    elseif (F_GRANGER13(i) <= alpha);
        Trech13(i,j)=0;
    end
    end
end
%FGRANGER14
for j=1:7    
    for i=1:R
    if  (F_GRANGER14(i,j) > alpha);
        Trech14(i,j)=1;
    elseif (F_GRANGER14(i) <= alpha);
        Trech14(i,j)=0;
    end
    end
end
%FGRANGER15
for j=1:7    
    for i=1:R
    if  (F_GRANGER15(i,j) > alpha);
        Trech15(i,j)=1;
    elseif (F_GRANGER15(i) <= alpha);
        Trech15(i,j)=0;
    end
    end
end
%FGRANGER16
for j=1:7    
    for i=1:R
    if  (F_GRANGER16(i,j) > alpha);
        Trech16(i,j)=1;
    elseif (F_GRANGER16(i) <= alpha);
        Trech16(i,j)=0;
    end
    end
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:7
R1(j)=(sum(Trech1(:,j)))/R;
R2(j)=(sum(Trech2(:,j)))/R;
R3(j)=(sum(Trech3(:,j)))/R;
R4(j)=(sum(Trech4(:,j)))/R;
R5(j)=(sum(Trech5(:,j)))/R;
R6(j)=(sum(Trech6(:,j)))/R;
R7(j)=(sum(Trech7(:,j)))/R;
R8(j)=(sum(Trech8(:,j)))/R;
R9(j)=(sum(Trech9(:,j)))/R;
R10(j)=(sum(Trech10(:,j)))/R;
R11(j)=(sum(Trech11(:,j)))/R;
R12(j)=(sum(Trech12(:,j)))/R;
R13(j)=(sum(Trech13(:,j)))/R;
R14(j)=(sum(Trech14(:,j)))/R;
R15(j)=(sum(Trech15(:,j)))/R;
R16(j)=(sum(Trech16(:,j)))/R;
end

RECH_TASA = [R1;R2;R3;R4;R5;R6;R7;R8;R9;R10;R11;R12;R13;R14;R15;R16]
toc
        