% m es el n�mero de repeticiones monte carlo
% T es el tama�o de muestra de la dist. muestral
% K es el tama�o de muestra de la dist. asint�tica

function test_asint(m,T,K)
tic
for i=1:m
avance=(100*i/m)
    F_GRANGER(i)=GC_SD(1,1,T);
   % FG_ASINT(i)=FG_TEO(K);
clc;
end

%f_fisher=frnd(1,499,10000,1);
%[fy,fx]=ksdensity(f_fisher);
%[h,stats] =cdfplot(FG_ASINT);

%linea=linspace(0,10,200);
%Y=fpdf(linea,1,9999);

%stats
%perc80=prctile(FG_ASINT,80);
%perc90=prctile(FG_ASINT,90);
%perc95=prctile(FG_ASINT,95);
%perc975=prctile(FG_ASINT,97.5)
%perc99=prctile(FG_ASINT,99);

perc80=prctile(F_GRANGER,80);
perc90=prctile(F_GRANGER,90);
perc95=prctile(F_GRANGER,95);
%perc975=prctile(FG_ASINT,97.5)
perc99=prctile(F_GRANGER,99);


PERC = [perc80;perc90;perc95;perc99]    
toc
%[a,b]=ksdensity(F_GRANGER);
% [c,d]=ksdensity(FG_ASINT);
% figure(1)
%subplot(211)
 %plot(b,a),hold on, plot(d,c,'r');
 %subplot(212)
 %cdfplot(F_GRANGER),hold on, cdfplot(FG_ASINT)
 
 %figure(2)
 %plot(d,c,'r'), hold on, plot(linea,Y)
 
 %figure(3)
 %cdfplot(F_GRANGER),hold on, cdfplot(FG_ASINT)
 
% figure(2)
% subplot(211)
% hist(F_GRANGER)
% subplot(212)
% hist(FG_ASINT)
% figure(3)
% cdfplot(F_GRANGER),hold on, cdfplot(FG_ASINT)
% figure(4)
% plot(fx,fy),hold on,plot(b,a,'r-')
% figure(5)
% plot(linea,Y);,hold on,plot(d,c,'r-')

