% PRUEBA DE GRANGER CAUSALIDAD

function [F_GRANGER]=GC_SD(sigmax,sigmay,T)

%MODELO NO RESTRINGIDO 
 
%RUIDOS PARA X y Y 
 Ux=normrnd(0,sigmax,T,1);
 Uy=normrnd(0,sigmay,T,1);

 y=cumsum(Uy);
 x=cumsum(Ux);

%GENERA DATOS PARA LA REGRESI�N Y(t)=Y(t-1)+X(t-1)+Uy,t

y_lag=y(1:T-1);
y_con=y(2:T);

x_lag=x(1:T-1);
x_con=x(2:T);

%ESTIMACI�N DE LA REGRESI�N VIA OLS
results=ols(y_con,[y_lag,x_lag]);
rcuad_aux= results.resid;
rcuad=rcuad_aux.^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%MODELO RESTRINGIDO 
 
%GENERA DATOS PARA LA REGRESI�N Y(t)=Y(t-1)+Uy,t

%ESTIMACI�N DE LA REGRESI�N VIA OLS
results_r=ols(y_con,[y_lag]);
rcuad_raux= results_r.resid;
rcuad_r=rcuad_raux.^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%C�LCULO DE F-STATISTIC DE GRANGER

RRSS=sum(rcuad_r);
URSS=sum(rcuad);

F_GRANGER= (RRSS-URSS)/(URSS/(T-1));
end


