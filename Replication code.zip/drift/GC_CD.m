% PRUEBA DE GRANGER CAUSALIDAD

function [F_GRANGER]=GC_CD(My,Mx,sigmax,sigmay,T)

%RUIDOS PARA X y Y 
Ux=normrnd(0,sigmax,T,1);
Uy=normrnd(0,sigmay,T,1);

t=cumsum(ones(T,1));
y=(My.*t)+cumsum(Uy);
x=(Mx.*t)+cumsum(Ux);

y_lag=y(1:T-1);
y_con=y(2:T);

x_lag=x(1:T-1);
x_con=x(2:T);

%MODELO NO RESTRINGIDO 
results=ols(y_con,[y_lag,x_lag]);
rcuad_aux= results.resid;
rcuad=rcuad_aux.^2;

%MODELO RESTRINGIDO 
 
results_r=ols(y_con,y_lag);
rcuad_raux= results_r.resid;
rcuad_r=rcuad_raux.^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%C�LCULO DE F-STATISTICS DE GRANGER

RRSS=sum(rcuad_r);
URSS=sum(rcuad);

F_GRANGER= T^(-1)*((RRSS-URSS)/(URSS/(T-1)));


