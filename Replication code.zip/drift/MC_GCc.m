%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estudio de la prueba de Granger Causalidad
% Procesos I(1) c/ drift
% Septiembre, 2010
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;  
R=1000;                          % N�mero de replicaciones
T=5000;
Ra=5000;
Sx=sqrt(1);
Sy=sqrt(1);

My=10.05;                       % Constante de Y
Mx=5.07;                        % Constante de X

Py=0.0;                         % AR(1) en el ruido de Y
Px=0.0;                         % AR(1) en el ruido de X
tiempo=cumsum(ones(T,1));
tps=cumsum(ones(Ra,1));
tic;
for j=1:R
% Generaci�n de los datos 
    x=Mx*tiempo+cumsum(randn(T,1));
    y=My*tiempo+cumsum(randn(T,1));
% Generaci�n de Brownianos:
    Ux=randn(Ra,1); Uy=randn(Ra,1); Sux=cumsum(Ux); Suy=cumsum(Uy);
    Ex=sum(Sux)/Ra^1.5; Ey=sum(Suy)/Ra^1.5; Ext=sum(Sux.*tps)/Ra^2.5;
    Eyt=sum(Suy.*tps)/Ra^2.5;   Ex2=sum(Sux.^2)/Ra^2;   Ey2=sum(Suy.^2)/Ra^2;
    Exy=sum(Sux.*Suy)/Ra^2; Uy2=1;  Ux2=1;    
% Prueba de Granger Causalidad simulada:
    REG_r=ols(y(2:T),y(1:T-1));
    A_rs(j)=REG_r.beta;
    A_rt=1;
    S_rs(j)=REG_r.sige;
    S_rt=0.25*(My^2+4);
    
    
    REG_u=ols(y(2:T),[y(1:T-1),x(2:T)]);
    A_us(j)=REG_r.beta(1);
    A_ut=1;
    B_us(j)=REG_u.beta(2)*T^0.5;
    B_ut(j)=-1*(My^2*(2*Ey*Mx-3*Eyt*Mx-2*Ex*My+3*Ext*My))/(2*(Ey2*Mx^2-...
            3*Eyt^2*Mx^2-2*Exy*Mx*My+6*Ext*Eyt*Mx*My+Ex2*My^2-3*Ext^2*My^2));    
    S_rs(j)=REG_r.sige;
    S_rt=0.25*(My^2+4);

    

 %   E_s0=GC_test(x,y);
 %   E_s(j)=E_s0(1)/T;
% Prueba de Granger Causalidad asint�tica:    
E_t(j)=-1*(My^2*(2*Ey*Mx-3*Eyt*Mx-2*Ex*My+3*Ext*My)^2)/(4*Ey^2*Mx^2*My^2-...
       Ey2*Mx^2*My^2-12*Ey*Eyt*Mx^2*My^2+12*Eyt^2*Mx^2*My^2+2*Exy*Mx*My^3-...
       8*Ex*Ey*Mx*My^3+12*Ext*Ey*Mx*My^3+12*Ex*Eyt*Mx*My^3-24*Ext*Eyt*Mx*My^3+...
       4*Ex^2*My^4-Ex2*My^4-12*Ex*Ext*My^4+12*Ext^2*My^4-4*Ey2*Mx^2*Uy2+...
       12*Eyt^2*Mx^2*Uy2+8*Exy*Mx*My*Uy2-24*Ext*Eyt*Mx*My*Uy2-4*Ex2*My^2*Uy2+...
       12*Ext^2*My^2*Uy2);
end;

[mean(A_rs),1];
[mean(S_rs),S_rt]

%[Ss,Ds]=noyau2(E_s,0.1);  [St,Dt]=noyau2(E_t,0.1);
[Ss,Ds]=noyau2(B_us,7);    [St,Dt]=noyau2(B_ut,7);

plot(Ss,Ds,'r',St,Dt,'b');

toc;