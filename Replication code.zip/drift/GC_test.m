% Comportamiento de la prueba de Granger causalidad bajo Ha

% GC I(0) REGRESION A

% GENERACION DE SERIES
function F_GRANGER=GC_test(T)

Mx = 10;
Mz = 10;
By1 = 10;

Uz= normrnd(0,1,T,1);
Ux= normrnd(0,1,T,1);
Uy= normrnd(0,1,T,1);

 y=Uy;
 x=Ux;
 z=Uz;

 y_lag=y(1:T-1);
y_con=y(2:T);

x_lag=x(1:T-1);
x_con=x(2:T);

% NO RESTRINGIDA

NR=ols(y_con,[y_lag,x_lag]);
sigma_NR = NR.resid.^2;

% RESTRINGIDA

R=ols(y_con,y_lag);
sigma_R = R.resid.^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%C�LCULO DE F  GRANGER

RRSS=sum(sigma_R);
URSS=sum(sigma_NR);

F_GRANGER= (RRSS-URSS)/(URSS/(T-1));

