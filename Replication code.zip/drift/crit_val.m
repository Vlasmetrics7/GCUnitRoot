% m: Monte Carlo replications

function crit_val

% Table 3
%test_asint(10000,20)
%test_asint(10000,50)
%test_asint(10000,100)
%test_asint(10000,250)
%test_asint(10000,500)
%test_asint(10000,1000)
%test_asint(10000,10000)

%Quantiles 95 , 99

tic
for i=1000:1000:100000
    i
    [FG_ASINT]=test_asint(10000,1,i);
    p95(i/100)=prctile(FG_ASINT,95);
    p99(i/100)=prctile(FG_ASINT,99);
end
toc
plot(p95), hold on, plot(p99,'r')