% R es repeticiones monte carlo
% alpha es el nivel cr�tico de la asint�tica
function  fa_rate_pr(R)
tic
Tb=[25,50,100,250,500,1000,10000];
alpha=1.70702;  %para My=Mx=1

for i=1:R
    avance=(100*i/R)
    for j=1:7
        T=Tb(j);
        F_GRANGER1(i,j)=GC_CD(10,10,1,1,T);
        F_GRANGER2(i,j)=GC_CD(20,20,1,1,T);
        F_GRANGER3(i,j)=GC_CD(30,30,1,1,T);
        F_GRANGER4(i,j)=GC_CD(40,40,1,1,T);
        F_GRANGER5(i,j)=GC_CD(50,50,1,1,T);
        F_GRANGER6(i,j)=GC_CD(60,60,1,1,T);
        F_GRANGER7(i,j)=GC_CD(70,70,1,1,T);
        F_GRANGER8(i,j)=GC_CD(80,80,1,1,T);
        F_GRANGER9(i,j)=GC_CD(90,90,1,1,T);
        F_GRANGER10(i,j)=GC_CD(100,100,1,1,T);
    end
    clc;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%FGRANGER1
for j=1:7    
    for i=1:R
    if  (F_GRANGER1(i,j) > alpha);
        Trech1(i,j)=1;
    elseif (F_GRANGER1(i) <= alpha);
        Trech1(i,j)=0;
    end
    end
end

%FGRANGER2
for j=1:7    
    for i=1:R
    if  (F_GRANGER2(i,j) > alpha);
        Trech2(i,j)=1;
    elseif (F_GRANGER2(i) <= alpha);
        Trech2(i,j)=0;
    end
    end
end
%FGRANGER3
for j=1:7    
    for i=1:R
    if  (F_GRANGER3(i,j) > alpha);
        Trech3(i,j)=1;
    elseif (F_GRANGER3(i) <= alpha);
        Trech3(i,j)=0;
    end
    end
end
%FGRANGER4
for j=1:7    
    for i=1:R
    if  (F_GRANGER4(i,j) > alpha);
        Trech4(i,j)=1;
    elseif (F_GRANGER4(i) <= alpha);
        Trech4(i,j)=0;
    end
    end
end
%FGRANGER5
for j=1:7    
    for i=1:R
    if  (F_GRANGER5(i,j) > alpha);
        Trech5(i,j)=1;
    elseif (F_GRANGER5(i) <= alpha);
        Trech5(i,j)=0;
    end
    end
end
%FGRANGER6
for j=1:7    
    for i=1:R
    if  (F_GRANGER6(i,j) > alpha);
        Trech6(i,j)=1;
    elseif (F_GRANGER6(i) <= alpha);
        Trech6(i,j)=0;
    end
    end
end
%FGRANGER7
for j=1:7    
    for i=1:R
    if  (F_GRANGER7(i,j) > alpha);
        Trech7(i,j)=1;
    elseif (F_GRANGER7(i) <= alpha);
        Trech7(i,j)=0;
    end
    end
end
%FGRANGER8
for j=1:7    
    for i=1:R
    if  (F_GRANGER8(i,j) > alpha);
        Trech8(i,j)=1;
    elseif (F_GRANGER8(i) <= alpha);
        Trech8(i,j)=0;
    end
    end
end
%FGRANGER9
for j=1:7    
    for i=1:R
    if  (F_GRANGER9(i,j) > alpha);
        Trech9(i,j)=1;
    elseif (F_GRANGER9(i) <= alpha);
        Trech9(i,j)=0;
    end
    end
end
%FGRANGER10
for j=1:7    
    for i=1:R
    if  (F_GRANGER10(i,j) > alpha);
        Trech10(i,j)=1;
    elseif (F_GRANGER10(i) <= alpha);
        Trech10(i,j)=0;
    end
    end
end

%end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:7
R1(j)=(sum(Trech1(:,j)))/R;
R2(j)=(sum(Trech2(:,j)))/R;
R3(j)=(sum(Trech3(:,j)))/R;
R4(j)=(sum(Trech4(:,j)))/R;
R5(j)=(sum(Trech5(:,j)))/R;
R6(j)=(sum(Trech6(:,j)))/R;
R7(j)=(sum(Trech7(:,j)))/R;
R8(j)=(sum(Trech8(:,j)))/R;
R9(j)=(sum(Trech9(:,j)))/R;
R10(j)=(sum(Trech10(:,j)))/R;
end
RECH_TASA = [R1;R2;R3;R4;R5;R6;R7;R8;R9;R10]
toc
