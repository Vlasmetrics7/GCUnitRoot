
function [FG_ASINT]=FG_TEO(T,My,Mx)

My=My;  Mx=Mx;

y=normrnd(0,1,T,1);Ey_cs=cumsum(y);
x=normrnd(0,1,T,1);Ex_cs=cumsum(x);

Ey=sum(Ey_cs)/(T^(3/2));
Ex=sum(Ex_cs)/(T^(3/2));

t=cumsum(ones(T,1));

Eyt= sum(t.*Ey_cs)/(T^(5/2));
Ext= sum(t.*Ex_cs)/(T^(5/2));


Exy=sum(Ey_cs.*Ex_cs)/(T^2);
Ey2=sum(Ey_cs.^2)/(T^2);
Ex2=sum(Ex_cs.^2)/(T^2);
Uy2=1;

FG_ASINT = -(My^2*((2*Ey*Mx - 3*Eyt*Mx - 2*Ex*My + 3*Ext*My)^2))/...
    (4*Ey^2*Mx^2*My^2-Ey2*Mx^2*My^2-12*Ey*Eyt*Mx^2*My^2+...
    12*Eyt^2*Mx^2*My^2+2*Exy*Mx*My^3-8*Ex*Ey*Mx*My^3+12*Ext*Ey*Mx*My^3+...
    12*Ex*Eyt*Mx*My^3-24*Ext*Eyt*Mx*My^3+4*Ex^2*My^4-Ex2*My^4-...
    12*Ex*Ext*My^4+12*Ext^2*My^4-4*Ey2*Mx^2*Uy2+12*Eyt^2*Mx^2*Uy2+...
    8*Exy*Mx*My*Uy2-24*Ext*Eyt*Mx*My*Uy2-4*Ex2*My^2*Uy2+12*Ext^2*My^2*Uy2);




